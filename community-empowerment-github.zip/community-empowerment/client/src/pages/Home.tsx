/*
 * DESIGN PHILOSOPHY: Solarpunk Commons
 * Forest green (#1a3a2a) primary | Amber gold accent | Parchment background
 * Playfair Display headings | Source Sans 3 body
 * Asymmetric layouts, diagonal cuts, organic warmth
 */

import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import TechnoFeudalismSection from "@/components/TechnoFeudalismSection";
import OptOutSection from "@/components/OptOutSection";
import SolarSection from "@/components/SolarSection";
import BroadbandSection from "@/components/BroadbandSection";
import PodCoinSection from "@/components/PodCoinSection";
import ActionGuideSection from "@/components/ActionGuideSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "oklch(0.97 0.015 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
      <Navbar />
      <Hero />
      <TechnoFeudalismSection />
      <OptOutSection />
      <SolarSection />
      <BroadbandSection />
      <PodCoinSection />
      <ActionGuideSection />
      <Footer />
    </div>
  );
}
