import { useEffect, useRef, useState } from "react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const principles = [
  { icon: "🔗", title: "Financial Autonomy", desc: "Blockchain enables transparent, automated transactions, allowing members to earn real value and reduce dependence on large ISPs." },
  { icon: "🗳️", title: "Democratic Governance", desc: "Community networks operate on models that allow for transparent voting on major network decisions." },
  { icon: "🌿", title: "Resilience & Redundancy", desc: "Decentralized networks are more resilient to failures; if one node goes down, data routes through others." },
  { icon: "♻️", title: "Environmental Sustainability", desc: "Decentralized networks allow for more efficient use of resources, reducing overall energy consumption." },
  { icon: "📣", title: "Policy Influence", desc: "Widespread adoption can encourage lawmakers to support more equitable forms of internet governance." },
];

export default function BroadbandSection() {
  const { ref, inView } = useInView();

  return (
    <section
      id="broadband"
      className="py-24"
      style={{ backgroundColor: "oklch(0.93 0.02 80)" }}
    >
      <div className="container mx-auto px-6 max-w-7xl" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-3 mb-4"
          style={{ opacity: inView ? 1 : 0, transition: "opacity 0.6s ease" }}
        >
          <span className="text-5xl font-black" style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.85 0.02 80)" }}>04</span>
          <div className="leaf-divider" />
          <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
            Decentralize the Internet
          </span>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Image + quote */}
          <div
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(-28px)",
              transition: "opacity 0.65s ease 0.1s, transform 0.65s ease 0.1s",
            }}
          >
            <div className="rounded-2xl overflow-hidden mb-8" style={{ boxShadow: "0 12px 48px oklch(0.28 0.09 155 / 0.15)" }}>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/117165971/EJnXzSUgo9uiqnKeCdVN32/photo-broadband_532eee5e.jpg"
                alt="Fiber optic broadband cable installation worker"
                className="w-full h-72 object-cover"
              />
            </div>

            <blockquote
              className="pl-5 py-3 text-xl italic leading-relaxed mb-6"
              style={{
                borderLeft: "4px solid oklch(0.78 0.16 72)",
                color: "oklch(0.28 0.09 155)",
                fontFamily: "'Playfair Display', serif",
                backgroundColor: "white",
                borderRadius: "0 8px 8px 0",
                paddingRight: "1.5rem",
              }}
            >
              "We envision a future where the Internet is a public commons, connecting communities much like the sidewalk connects your neighborhood."
              <footer
                className="mt-2 text-sm not-italic font-semibold"
                style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}
              >
                — Dr. Ron Suarez, Executive Director, Broadband Institute Foundation
              </footer>
            </blockquote>

            {/* Michigan example */}
            <div
              className="rounded-xl p-6"
              style={{
                backgroundColor: "oklch(0.28 0.09 155)",
                boxShadow: "0 4px 20px oklch(0.28 0.09 155 / 0.2)",
              }}
            >
              <h4
                className="text-lg font-bold mb-3"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.78 0.16 72)" }}
              >
                Michigan: Community Broadband in Action
              </h4>
              <p className="text-sm leading-relaxed mb-3" style={{ color: "oklch(0.88 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
                In Ann Arbor, BIF worked with 123Net to deliver <strong style={{ color: "oklch(0.78 0.16 72)" }}>free internet service to 50 affordable housing units</strong> at the Veridian at County Farm "net zero" project. Electricity and internet savings for participating households are estimated at <strong style={{ color: "oklch(0.78 0.16 72)" }}>$3,600 annually</strong>.
              </p>
              <p className="text-sm leading-relaxed mb-4" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
                This was achieved by advising residents to purchase one wholesale connection collectively through their homeowners association fees — a model any neighborhood can replicate.
              </p>
              <a
                href="https://communityinter.net/collaborative-networks-empower-michigan-communities-with-affordable-community-owned-broadband-solutions/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-semibold link-underline"
                style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Source Sans 3', sans-serif" }}
              >
                Read the full story →
              </a>
            </div>
          </div>

          {/* Right: text + principles */}
          <div
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(28px)",
              transition: "opacity 0.65s ease 0.25s, transform 0.65s ease 0.25s",
            }}
          >
            <h2
              className="text-4xl md:text-5xl font-bold leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.22 0.01 65)" }}
            >
              Community-Owned{" "}
              <em style={{ color: "oklch(0.28 0.09 155)" }}>Broadband</em>
            </h2>
            <p className="text-lg leading-relaxed mb-5" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
              Just as energy can be decentralized, so too can internet access. The Broadband Institute Foundation (BIF) helps communities build and manage their own broadband networks, keeping costs low and reinvesting benefits locally.
            </p>
            <p className="text-lg leading-relaxed mb-8" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
              This approach is rooted in <strong>Commons-Based Peer Production (CBPP)</strong> — a model that converts consumers into "prosumers." Utilizing blockchain technology and specialized routing software like Althea.net, individuals can purchase bandwidth from upstream providers and sell it to neighbors downstream, creating a peer-to-peer internet commons.
            </p>

            <h3
              className="text-xl font-bold mb-5"
              style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.22 0.01 65)" }}
            >
              Key Principles of Community-Owned Broadband
            </h3>

            <div className="space-y-4">
              {principles.map((p) => (
                <div
                  key={p.title}
                  className="flex gap-4 p-4 rounded-xl card-lift"
                  style={{
                    backgroundColor: "white",
                    border: "1px solid oklch(0.88 0.025 80)",
                    boxShadow: "0 2px 8px oklch(0.28 0.09 155 / 0.05)",
                  }}
                >
                  <span className="text-2xl flex-shrink-0">{p.icon}</span>
                  <div>
                    <h4
                      className="font-bold mb-1"
                      style={{ color: "oklch(0.28 0.09 155)", fontFamily: "'Source Sans 3', sans-serif" }}
                    >
                      {p.title}
                    </h4>
                    <p className="text-sm leading-relaxed" style={{ color: "oklch(0.45 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
                      {p.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <p
              className="mt-6 text-sm"
              style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}
            >
              Sources:{" "}
              <a href="https://communityinter.net/collaborative-networks-empower-michigan-communities-with-affordable-community-owned-broadband-solutions/" target="_blank" rel="noopener noreferrer" className="link-underline font-medium" style={{ color: "oklch(0.28 0.09 155)" }}>CommunityInternet.coop</a>
              {" "}|{" "}
              <a href="https://communityinter.net/cbpp/" target="_blank" rel="noopener noreferrer" className="link-underline font-medium" style={{ color: "oklch(0.28 0.09 155)" }}>CBPP Commons-Based Peer Production</a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
