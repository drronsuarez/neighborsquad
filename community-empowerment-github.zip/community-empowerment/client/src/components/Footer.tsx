const references = [
  { num: 1, title: "8 billion people vs 5 AI CEOs with Tristan Harris", source: "YouTube", href: "https://youtu.be/A6wLhQgGuyU" },
  { num: 2, title: "What we know about energy use at U.S. data centers amid the AI boom", source: "Pew Research Center, 2025", href: "https://www.pewresearch.org/short-reads/2025/10/24/what-we-know-about-energy-use-at-us-data-centers-amid-the-ai-boom/" },
  { num: 3, title: "Proton: Privacy by default", source: "Proton.me", href: "https://proton.me" },
  { num: 4, title: "Europe Rejects Energy Crisis With Balcony Solar", source: "House of El, YouTube", href: "https://youtu.be/bt1qBKW7nGY" },
  { num: 5, title: "The DIY Solar Revolution Is Coming to U.S. Balconies", source: "Reasons to be Cheerful, 2026", href: "https://reasonstobecheerful.world/diy-balcony-solar-revolution-america/" },
  { num: 6, title: "Affordable, Community-Owned Internet & Electricity Eco-solutions", source: "CommunityInternet / BIF", href: "https://communityinter.net/collaborative-networks-empower-michigan-communities-with-affordable-community-owned-broadband-solutions/" },
  { num: 7, title: "CBPP Commons-Based Peer Production", source: "CommunityInternet", href: "https://communityinter.net/cbpp/" },
  { num: 8, title: "No Kings: Imagine, Plan, Build Pods", source: "PodCOIN", href: "https://podcoin.org/no-kings-imagine-plan-build-pods/" },
  { num: 9, title: "Be The Change — PodCOIN", source: "PodCOIN", href: "https://podcoin.org" },
];

const quickLinks = [
  { label: "The Threat", href: "#threat" },
  { label: "Opt Out", href: "#opt-out" },
  { label: "Balcony Solar", href: "#solar" },
  { label: "Community Broadband", href: "#broadband" },
  { label: "PodCOIN", href: "#podcoin" },
  { label: "Take Action", href: "#action" },
];

const resources = [
  { label: "PodCOIN", href: "https://podcoin.org" },
  { label: "CommunityInternet.coop", href: "https://communityinter.net" },
  { label: "Proton Mail", href: "https://proton.me" },
  { label: "Signal Messenger", href: "https://signal.org" },
  { label: "Brave Browser", href: "https://brave.com" },
  { label: "Jitsi Meet", href: "https://meet.jit.si" },
];

export default function Footer() {
  return (
    <footer style={{ backgroundColor: "oklch(0.14 0.06 155)" }}>
      {/* References section */}
      <div className="container mx-auto px-6 max-w-7xl py-16">
        <h3
          className="text-xl font-bold mb-8"
          style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.78 0.16 72)" }}
        >
          References &amp; Sources
        </h3>
        <div className="grid md:grid-cols-2 gap-3 mb-16">
          {references.map((ref) => (
            <div key={ref.num} className="flex gap-3 items-start">
              <span
                className="text-xs font-bold w-6 h-6 rounded flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{
                  backgroundColor: "oklch(0.28 0.09 155)",
                  color: "oklch(0.78 0.16 72)",
                  fontFamily: "'Source Sans 3', sans-serif",
                }}
              >
                {ref.num}
              </span>
              <div>
                <a
                  href={ref.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm link-underline"
                  style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  {ref.title}
                </a>
                <span className="text-xs ml-2" style={{ color: "oklch(0.55 0.04 80)" }}>— {ref.source}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer grid */}
        <div className="grid md:grid-cols-3 gap-12 pb-12 border-b" style={{ borderColor: "oklch(0.22 0.08 155)" }}>
          {/* Brand */}
          <div>
            <div
              className="text-2xl font-bold mb-4"
              style={{ fontFamily: "'Playfair Display', serif", color: "white" }}
            >
              Community<span style={{ color: "oklch(0.78 0.16 72)" }}>Power</span>
            </div>
            <p className="text-sm leading-relaxed mb-4" style={{ color: "oklch(0.65 0.04 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              A guide for families and neighbors to decentralize energy and internet access, opt out of corporate surveillance, and build community power through open-source tools and cooperative economics.
            </p>
            <p className="text-xs" style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              Published by Dr. Ron Suarez / CommunityInternet.coop
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h4
              className="text-sm font-bold uppercase tracking-widest mb-4"
              style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Source Sans 3', sans-serif" }}
            >
              On This Page
            </h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm link-underline"
                    style={{ color: "oklch(0.72 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4
              className="text-sm font-bold uppercase tracking-widest mb-4"
              style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Source Sans 3', sans-serif" }}
            >
              Key Resources
            </h4>
            <ul className="space-y-2">
              {resources.map((r) => (
                <li key={r.href}>
                  <a
                    href={r.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm link-underline"
                    style={{ color: "oklch(0.72 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {r.label} ↗
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs" style={{ color: "oklch(0.45 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
            © 2026 CommunityInternet.coop — Content freely shared under Creative Commons CC BY-SA 4.0
          </p>
          <p className="text-xs" style={{ color: "oklch(0.45 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
            Built with open-source tools. No surveillance. No tracking.
          </p>
        </div>
      </div>
    </footer>
  );
}
