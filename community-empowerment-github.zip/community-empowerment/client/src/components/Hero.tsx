import { useEffect, useState } from "react";

export default function Hero() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden diagonal-cut"
      style={{
        background: "oklch(0.18 0.07 155)",
      }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/117165971/EJnXzSUgo9uiqnKeCdVN32/photo-hero-neighbors_c5a04ac0.jpg')`,
          opacity: 0.35,
        }}
      />
      {/* Gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, oklch(0.18 0.07 155 / 0.85) 0%, oklch(0.18 0.07 155 / 0.55) 60%, oklch(0.28 0.09 155 / 0.7) 100%)",
        }}
      />

      <div className="container relative z-10 mx-auto px-6 max-w-7xl py-32 pt-40">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-semibold mb-6"
            style={{
              backgroundColor: "oklch(0.78 0.16 72 / 0.2)",
              border: "1px solid oklch(0.78 0.16 72 / 0.5)",
              color: "oklch(0.88 0.12 72)",
              fontFamily: "'Source Sans 3', sans-serif",
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(16px)",
              transition: "opacity 0.6s ease, transform 0.6s ease",
            }}
          >
            <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
            Community Action Guide
          </div>

          {/* Main headline */}
          <h1
            className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "white",
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(24px)",
              transition: "opacity 0.7s ease 0.1s, transform 0.7s ease 0.1s",
            }}
          >
            Opt Out of{" "}
            <span style={{ color: "oklch(0.78 0.16 72)" }}>Technofeudalism</span>
            <br />
            Build Community{" "}
            <span
              className="italic"
              style={{ color: "oklch(0.68 0.1 155)" }}
            >
              Power
            </span>
          </h1>

          {/* Subheadline */}
          <p
            className="text-xl md:text-2xl leading-relaxed mb-10 max-w-2xl"
            style={{
              color: "oklch(0.88 0.02 80)",
              fontFamily: "'Source Sans 3', sans-serif",
              fontWeight: 300,
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(20px)",
              transition: "opacity 0.7s ease 0.2s, transform 0.7s ease 0.2s",
            }}
          >
            How families can organize neighbors to decentralize electricity and internet,
            stop mass surveillance, and use open-source tools to reclaim sovereignty.
            <strong style={{ color: "oklch(0.88 0.12 72)", fontWeight: 600 }}>
              {" "}Opting out is more powerful than protest.
            </strong>
          </p>

          {/* CTA buttons */}
          <div
            className="flex flex-wrap gap-4"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(16px)",
              transition: "opacity 0.7s ease 0.35s, transform 0.7s ease 0.35s",
            }}
          >
            <a
              href="#threat"
              className="px-8 py-4 rounded-full font-semibold text-base transition-all duration-200"
              style={{
                backgroundColor: "oklch(0.78 0.16 72)",
                color: "oklch(0.18 0.07 155)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.backgroundColor = "oklch(0.88 0.12 72)";
                (e.target as HTMLElement).style.transform = "scale(1.03)";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72)";
                (e.target as HTMLElement).style.transform = "scale(1)";
              }}
            >
              Read the Guide ↓
            </a>
            <a
              href="https://podcoin.org"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 rounded-full font-semibold text-base transition-all duration-200"
              style={{
                border: "2px solid oklch(0.78 0.16 72 / 0.6)",
                color: "oklch(0.88 0.12 72)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72 / 0.15)";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.backgroundColor = "transparent";
              }}
            >
              Join PodCOIN →
            </a>
          </div>
        </div>

        {/* Stat bar */}
        <div
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6"
          style={{
            opacity: visible ? 1 : 0,
            transition: "opacity 0.8s ease 0.5s",
          }}
        >
          {[
            { value: "183 TWh", label: "US data center electricity 2024", source: "Pew Research" },
            { value: "4M+", label: "Balcony solar installs in Germany", source: "House of El" },
            { value: "$3,600", label: "Annual savings per household", source: "CommunityInternet" },
            { value: "5 CEOs", label: "Control 8 billion people's AI", source: "Tristan Harris" },
          ].map((stat) => (
            <div
              key={stat.value}
              className="rounded-xl p-4"
              style={{
                backgroundColor: "oklch(0.97 0.015 80 / 0.08)",
                border: "1px solid oklch(0.78 0.16 72 / 0.25)",
              }}
            >
              <div
                className="text-3xl font-black mb-1 stat-glow"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.78 0.16 72)" }}
              >
                {stat.value}
              </div>
              <div className="text-sm leading-snug" style={{ color: "oklch(0.88 0.02 80)" }}>
                {stat.label}
              </div>
              <div className="text-xs mt-1" style={{ color: "oklch(0.65 0.05 80)" }}>
                — {stat.source}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
