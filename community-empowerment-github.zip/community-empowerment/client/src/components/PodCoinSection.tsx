import { useEffect, useRef, useState } from "react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const pillars = [
  {
    num: "01",
    title: "Imagine",
    desc: "Crowdsource ideas and think bigger about community infrastructure. What does your neighborhood need? What can you build together?",
    icon: "💡",
  },
  {
    num: "02",
    title: "Plan",
    desc: "Organize community plans through meeting places, peer-to-peer learning, and a marketplace. Form pods of 4–6 people for focused action.",
    icon: "📋",
  },
  {
    num: "03",
    title: "Build",
    desc: "Construct better futures through open-source tools, liquid infrastructure financing, and local community ownership. An investment could cover 10 miles or 10 feet of fiber optic.",
    icon: "🔨",
  },
];

export default function PodCoinSection() {
  const { ref, inView } = useInView();

  return (
    <section
      id="podcoin"
      className="py-24"
      style={{ backgroundColor: "oklch(0.18 0.07 155)" }}
    >
      <div className="container mx-auto px-6 max-w-7xl" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-3 mb-4"
          style={{ opacity: inView ? 1 : 0, transition: "opacity 0.6s ease" }}
        >
          <span className="text-5xl font-black" style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.28 0.09 155)" }}>05</span>
          <div className="leaf-divider" />
          <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Source Sans 3', sans-serif" }}>
            Community Economy
          </span>
        </div>

        {/* Headline */}
        <div
          className="text-center max-w-3xl mx-auto mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(28px)",
            transition: "opacity 0.65s ease 0.1s, transform 0.65s ease 0.1s",
          }}
        >
          <h2
            className="text-4xl md:text-5xl font-bold leading-tight mb-6"
            style={{ fontFamily: "'Playfair Display', serif", color: "white" }}
          >
            Organize Neighbors &amp; Drive Policy Change with{" "}
            <a
              href="https://podcoin.org"
              target="_blank"
              rel="noopener noreferrer"
              className="link-underline"
              style={{ color: "oklch(0.78 0.16 72)" }}
            >
              PodCOIN
            </a>
          </h2>
          <p className="text-xl leading-relaxed" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif", fontWeight: 300 }}>
            PodCOIN facilitates the building of <strong style={{ color: "oklch(0.78 0.16 72)", fontWeight: 600 }}>Community Owned Infrastructure Networks (COINs)</strong> by enabling liquid infrastructure financing and local community ownership. By orchestrating cashless transactions and tokenizing the work members do for each other, communities can create regenerative, circular economies.
          </p>
        </div>

        {/* Three pillars */}
        <div
          className="grid md:grid-cols-3 gap-8 mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(24px)",
            transition: "opacity 0.65s ease 0.25s, transform 0.65s ease 0.25s",
          }}
        >
          {pillars.map((p) => (
            <div
              key={p.num}
              className="rounded-2xl p-8 card-lift"
              style={{
                backgroundColor: "oklch(0.22 0.08 155)",
                border: "1px solid oklch(0.32 0.09 155)",
              }}
            >
              <div
                className="text-4xl font-black mb-2"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.38 0.09 155)" }}
              >
                {p.num}
              </div>
              <div className="text-3xl mb-4">{p.icon}</div>
              <h3
                className="text-2xl font-bold mb-3"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.78 0.16 72)" }}
              >
                {p.title}
              </h3>
              <p className="text-base leading-relaxed" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
                {p.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Pod model callout */}
        <div
          className="grid lg:grid-cols-2 gap-12 items-center"
          style={{
            opacity: inView ? 1 : 0,
            transition: "opacity 0.65s ease 0.4s",
          }}
        >
          <div
            className="rounded-2xl p-8"
            style={{
              backgroundColor: "oklch(0.78 0.16 72 / 0.12)",
              border: "1px solid oklch(0.78 0.16 72 / 0.3)",
            }}
          >
            <h3
              className="text-2xl font-bold mb-4"
              style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.88 0.12 72)" }}
            >
              The Pod Model: Small Groups, Big Change
            </h3>
            <p className="text-base leading-relaxed mb-4" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              The "pod" model — small, agile groups of 4 to 6 people — provides a proven framework for strategic planning and decentralized action. This model draws inspiration from the organizing principles of Occupy Wall Street, which coordinated 9,000 people in 82 groups through home-based meet-ups, and from the farm-worker organizing of Cesar Chavez.
            </p>
            <p className="text-base leading-relaxed mb-6" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              By forming purpose-driven pods, neighbors can collaborate on concrete local wins: advocating for zoning reforms, launching community solar projects, or building local internet networks.
            </p>
            <a
              href="https://podcoin.org/no-kings-imagine-plan-build-pods/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full font-semibold text-sm transition-all duration-200"
              style={{
                backgroundColor: "oklch(0.78 0.16 72)",
                color: "oklch(0.18 0.07 155)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.88 0.12 72)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72)"; }}
            >
              Read: No Kings — Imagine, Plan, Build Pods →
            </a>
          </div>

          <div>
            <h3
              className="text-2xl font-bold mb-5"
              style={{ fontFamily: "'Playfair Display', serif", color: "white" }}
            >
              Economic Autonomy = Political Power
            </h3>
            <p className="text-base leading-relaxed mb-6" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              When communities control their own infrastructure and financial exchanges, they can bypass political gridlock and drive public policy change from the ground up. The strategy mirrors the insight of Occupy Wall Street: a simple, powerful narrative combined with decentralized, local action can shift the entire political conversation.
            </p>

            {/* Key features */}
            {[
              { label: "Cashless Community Transactions", desc: "Tokenize the work members do for each other, creating a local circular economy independent of corporate financial systems." },
              { label: "Liquid Infrastructure Financing", desc: "An investment could cover '10 miles or 10 feet of fiber optic' — making infrastructure ownership accessible to everyone." },
              { label: "Community Owned Infrastructure Networks", desc: "COINs give communities direct ownership of the broadband, energy, and economic tools they depend on." },
            ].map((f) => (
              <div
                key={f.label}
                className="flex gap-3 mb-4"
              >
                <div
                  className="w-2 h-2 rounded-full mt-2 flex-shrink-0"
                  style={{ backgroundColor: "oklch(0.78 0.16 72)" }}
                />
                <div>
                  <span className="font-semibold" style={{ color: "oklch(0.88 0.12 72)", fontFamily: "'Source Sans 3', sans-serif" }}>
                    {f.label}:{" "}
                  </span>
                  <span style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
                    {f.desc}
                  </span>
                </div>
              </div>
            ))}

            <a
              href="https://podcoin.org"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-4 px-6 py-3 rounded-full font-semibold text-sm transition-all duration-200"
              style={{
                border: "2px solid oklch(0.78 0.16 72 / 0.5)",
                color: "oklch(0.78 0.16 72)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72 / 0.1)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
            >
              Visit podcoin.org →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
