import { useEffect, useRef, useState } from "react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const tools = [
  { corporate: "Gmail", alternative: "Proton Mail", url: "https://proton.me", benefit: "End-to-end encryption; no data mining", icon: "✉️" },
  { corporate: "Google Chrome", alternative: "Firefox / Brave", url: "https://brave.com", benefit: "Blocks trackers; open-source codebase", icon: "🌐" },
  { corporate: "Facebook / Instagram", alternative: "Mastodon / Pixelfed", url: "https://mastodon.social", benefit: "Decentralized; no algorithmic manipulation", icon: "📱" },
  { corporate: "Google Drive", alternative: "Nextcloud / Proton Drive", url: "https://proton.me/drive", benefit: "Self-hosted or privacy-first cloud storage", icon: "☁️" },
  { corporate: "WhatsApp", alternative: "Signal", url: "https://signal.org", benefit: "Open-source; zero-knowledge encryption", icon: "💬" },
  { corporate: "Google Search", alternative: "DuckDuckGo / Brave Search", url: "https://duckduckgo.com", benefit: "No search history profiling", icon: "🔍" },
  { corporate: "Zoom", alternative: "Jitsi Meet", url: "https://meet.jit.si", benefit: "Open-source; no account required", icon: "📹" },
];

export default function OptOutSection() {
  const { ref, inView } = useInView();

  return (
    <section
      id="opt-out"
      className="py-24 diagonal-cut-reverse"
      style={{ backgroundColor: "oklch(0.28 0.09 155)" }}
    >
      <div className="container mx-auto px-6 max-w-7xl" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-3 mb-4"
          style={{
            opacity: inView ? 1 : 0,
            transition: "opacity 0.6s ease",
          }}
        >
          <span
            className="text-5xl font-black"
            style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.38 0.09 155)" }}
          >
            02
          </span>
          <div className="leaf-divider" />
          <span
            className="text-sm font-semibold uppercase tracking-widest"
            style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Source Sans 3', sans-serif" }}
          >
            Opt Out
          </span>
        </div>

        <div className="grid lg:grid-cols-5 gap-12 items-start">
          {/* Left: text */}
          <div
            className="lg:col-span-2"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateY(0)" : "translateY(28px)",
              transition: "opacity 0.65s ease 0.1s, transform 0.65s ease 0.1s",
            }}
          >
            <h2
              className="text-4xl md:text-5xl font-bold leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif", color: "white" }}
            >
              Opting Out is More Powerful Than{" "}
              <em style={{ color: "oklch(0.78 0.16 72)" }}>Protest</em>
            </h2>
            <p className="text-lg leading-relaxed mb-5" style={{ color: "oklch(0.88 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              Protesting against tech monopolies often falls on deaf ears, but opting out starves them of their most valuable resource: your data and your attention. When millions of people collectively withdraw from corporate surveillance platforms, they undermine the economic foundation of the entire technofeudal system.
            </p>
            <p className="text-lg leading-relaxed mb-8" style={{ color: "oklch(0.88 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              Proton Mail, for example, is powered by community subscriptions rather than advertising revenue. Over 100 million people have already made the switch — each one shrinking the data pool that feeds mass surveillance infrastructure.
            </p>

            {/* Image */}
            <div className="rounded-2xl overflow-hidden" style={{ boxShadow: "0 8px 40px oklch(0.18 0.07 155 / 0.5)" }}>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/117165971/EJnXzSUgo9uiqnKeCdVN32/photo-privacy-laptop_d8d38663.jpg"
                alt="Open source privacy tools on a solarpunk desk"
                className="w-full h-64 object-cover"
              />
            </div>
          </div>

          {/* Right: tools table */}
          <div
            className="lg:col-span-3"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(28px)",
              transition: "opacity 0.65s ease 0.25s, transform 0.65s ease 0.25s",
            }}
          >
            <div
              className="rounded-2xl overflow-hidden"
              style={{ border: "1px solid oklch(0.38 0.09 155)", boxShadow: "0 8px 40px oklch(0.18 0.07 155 / 0.4)" }}
            >
              {/* Table header */}
              <div
                className="grid grid-cols-3 px-5 py-3 text-xs font-bold uppercase tracking-widest"
                style={{
                  backgroundColor: "oklch(0.18 0.07 155)",
                  color: "oklch(0.78 0.16 72)",
                  fontFamily: "'Source Sans 3', sans-serif",
                }}
              >
                <span>Corporate Tool</span>
                <span>Open Alternative</span>
                <span className="hidden md:block">Key Benefit</span>
              </div>

              {tools.map((tool, i) => (
                <div
                  key={tool.corporate}
                  className="grid grid-cols-3 px-5 py-4 items-center transition-colors duration-150"
                  style={{
                    backgroundColor: i % 2 === 0 ? "oklch(0.22 0.08 155)" : "oklch(0.25 0.08 155)",
                    borderTop: "1px solid oklch(0.32 0.09 155)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.32 0.09 155)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.backgroundColor = i % 2 === 0 ? "oklch(0.22 0.08 155)" : "oklch(0.25 0.08 155)";
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{tool.icon}</span>
                    <span className="text-sm" style={{ color: "oklch(0.75 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
                      {tool.corporate}
                    </span>
                  </div>
                  <a
                    href={tool.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-semibold link-underline"
                    style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {tool.alternative}
                  </a>
                  <span
                    className="text-xs leading-snug hidden md:block"
                    style={{ color: "oklch(0.75 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}
                  >
                    {tool.benefit}
                  </span>
                </div>
              ))}
            </div>

            <p
              className="mt-4 text-sm text-center"
              style={{ color: "oklch(0.65 0.05 80)", fontFamily: "'Source Sans 3', sans-serif" }}
            >
              Each switch is a vote for a different kind of internet — one that serves people, not surveillance.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
