import { useEffect, useRef, useState } from "react";

function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export default function TechnoFeudalismSection() {
  const { ref, inView } = useInView();

  return (
    <section id="threat" className="py-24 relative" style={{ backgroundColor: "oklch(0.97 0.015 80)" }}>
      <div className="container mx-auto px-6 max-w-7xl" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-3 mb-4"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
          }}
        >
          <span
            className="text-5xl font-black"
            style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.88 0.025 80)" }}
          >
            01
          </span>
          <div className="leaf-divider" />
          <span
            className="text-sm font-semibold uppercase tracking-widest"
            style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}
          >
            The Threat
          </span>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Text */}
          <div
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateY(0)" : "translateY(28px)",
              transition: "opacity 0.65s ease 0.1s, transform 0.65s ease 0.1s",
            }}
          >
            <h2
              className="text-4xl md:text-5xl font-bold leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.22 0.01 65)" }}
            >
              Technofeudalism &amp; the Energy Cost of{" "}
              <em style={{ color: "oklch(0.28 0.09 155)" }}>Surveillance</em>
            </h2>
            <p className="text-lg leading-relaxed mb-5" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
              The business models of major social media platforms like Facebook are fundamentally extractive. They rely on engagement algorithms that foster addiction, distraction, and polarization — functioning as corporate surveillance tools that harvest behavioral data at scale.
            </p>
            <p className="text-lg leading-relaxed mb-5" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
              As Tristan Harris, co-founder of the Center for Humane Technology, argues: without meaningful regulation, AI could be weaponized for domestic surveillance, behavioral manipulation, and social control. In simulated war games, AI models have repeatedly escalated conflicts to the point of nuclear threats.
            </p>

            {/* Blockquote */}
            <blockquote
              className="pl-5 py-3 my-6 text-xl italic leading-relaxed"
              style={{
                borderLeft: "4px solid oklch(0.78 0.16 72)",
                color: "oklch(0.28 0.09 155)",
                fontFamily: "'Playfair Display', serif",
                backgroundColor: "oklch(0.93 0.02 80)",
                borderRadius: "0 8px 8px 0",
                paddingRight: "1.5rem",
              }}
            >
              "The technofeudalists need more electricity to do mass surveillance and power autonomous weapons that threaten humanity. Every kilowatt-hour you generate yourself is one less they can claim."
            </blockquote>

            <p className="text-sm" style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
              Source:{" "}
              <a
                href="https://youtu.be/A6wLhQgGuyU"
                target="_blank"
                rel="noopener noreferrer"
                className="link-underline font-medium"
                style={{ color: "oklch(0.28 0.09 155)" }}
              >
                8 billion people vs 5 AI CEOs with Tristan Harris
              </a>
            </p>
          </div>

          {/* Stats panel */}
          <div
            className="space-y-5"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(28px)",
              transition: "opacity 0.65s ease 0.25s, transform 0.65s ease 0.25s",
            }}
          >
            {[
              {
                icon: "⚡",
                stat: "183 TWh",
                desc: "US data center electricity consumption in 2024 — equivalent to the annual demand of Pakistan",
                source: "Pew Research Center, 2025",
                href: "https://www.pewresearch.org/short-reads/2025/10/24/what-we-know-about-energy-use-at-us-data-centers-amid-the-ai-boom/",
              },
              {
                icon: "📈",
                stat: "+133% by 2030",
                desc: "Projected growth in US data center electricity demand — driven almost entirely by AI surveillance infrastructure",
                source: "IEA via Pew Research",
                href: "https://www.pewresearch.org/short-reads/2025/10/24/what-we-know-about-energy-use-at-us-data-centers-amid-the-ai-boom/",
              },
              {
                icon: "💧",
                stat: "17 Billion Gallons",
                desc: "Water consumed directly by US data centers in 2023, with hyperscale AI facilities using the lion's share",
                source: "Berkeley Lab / US Dept. of Energy",
                href: "https://www.pewresearch.org/short-reads/2025/10/24/what-we-know-about-energy-use-at-us-data-centers-amid-the-ai-boom/",
              },
              {
                icon: "🏰",
                stat: "5 Companies",
                desc: "Control the AI systems shaping the lives of 8 billion people — a concentration of power unprecedented in human history",
                source: "Tristan Harris, On with Kara Swisher",
                href: "https://youtu.be/A6wLhQgGuyU",
              },
            ].map((item) => (
              <div
                key={item.stat}
                className="rounded-xl p-5 card-lift"
                style={{
                  backgroundColor: "white",
                  border: "1px solid oklch(0.88 0.025 80)",
                  boxShadow: "0 2px 12px oklch(0.28 0.09 155 / 0.06)",
                }}
              >
                <div className="flex items-start gap-4">
                  <span className="text-3xl">{item.icon}</span>
                  <div>
                    <div
                      className="text-2xl font-black mb-1"
                      style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.28 0.09 155)" }}
                    >
                      {item.stat}
                    </div>
                    <p className="text-sm leading-relaxed mb-2" style={{ color: "oklch(0.35 0.02 65)" }}>
                      {item.desc}
                    </p>
                    <a
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs link-underline"
                      style={{ color: "oklch(0.52 0.03 80)" }}
                    >
                      — {item.source}
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
