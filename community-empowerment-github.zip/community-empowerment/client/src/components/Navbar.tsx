import { useState, useEffect } from "react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { label: "The Threat", href: "#threat" },
    { label: "Opt Out", href: "#opt-out" },
    { label: "Solar", href: "#solar" },
    { label: "Broadband", href: "#broadband" },
    { label: "PodCOIN", href: "#podcoin" },
    { label: "Take Action", href: "#action" },
  ];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        backgroundColor: scrolled ? "oklch(0.18 0.07 155 / 0.97)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        boxShadow: scrolled ? "0 2px 24px oklch(0.18 0.07 155 / 0.3)" : "none",
      }}
    >
      <div className="container mx-auto px-6 py-4 flex items-center justify-between max-w-7xl">
        <a href="#" className="flex items-center gap-2">
          <span
            className="text-lg font-bold tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif", color: scrolled ? "oklch(0.97 0.015 80)" : "white" }}
          >
            Community<span style={{ color: "oklch(0.78 0.16 72)" }}>Power</span>
          </span>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium transition-colors duration-200 link-underline"
              style={{
                color: scrolled ? "oklch(0.88 0.02 80)" : "rgba(255,255,255,0.9)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
            >
              {link.label}
            </a>
          ))}
          <a
            href="https://podcoin.org"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200"
            style={{
              backgroundColor: "oklch(0.78 0.16 72)",
              color: "oklch(0.18 0.07 155)",
              fontFamily: "'Source Sans 3', sans-serif",
            }}
            onMouseEnter={(e) => {
              (e.target as HTMLElement).style.backgroundColor = "oklch(0.88 0.12 72)";
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72)";
            }}
          >
            Join PodCOIN →
          </a>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="block w-6 h-0.5 transition-all duration-200"
              style={{ backgroundColor: scrolled ? "oklch(0.97 0.015 80)" : "white" }}
            />
          ))}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden px-6 pb-6 pt-2"
          style={{ backgroundColor: "oklch(0.18 0.07 155 / 0.97)" }}
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="block py-3 text-base font-medium border-b"
              style={{
                color: "oklch(0.88 0.02 80)",
                borderColor: "oklch(0.28 0.09 155)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}
