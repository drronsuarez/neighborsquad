import { useEffect, useRef, useState } from "react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const steps = [
  {
    step: "1",
    action: "Gather",
    how: "Host a neighborhood potluck or 'Odd Friday' gathering",
    outcome: "Build trust and identify shared concerns",
    icon: "🤝",
  },
  {
    step: "2",
    action: "Assess",
    how: "Audit local energy and internet costs and providers",
    outcome: "Identify opportunities for collective savings",
    icon: "📊",
  },
  {
    step: "3",
    action: "Opt Out",
    how: "Switch to Proton Mail, Signal, and privacy-first tools",
    outcome: "Reduce data footprint and corporate surveillance revenue",
    icon: "🔒",
  },
  {
    step: "4",
    action: "Generate",
    how: "Install balcony solar panels; explore community solar cooperatives",
    outcome: "Reduce electricity bills and grid dependence",
    icon: "☀️",
  },
  {
    step: "5",
    action: "Connect",
    how: "Explore community broadband options through CommunityInternet.coop",
    outcome: "Achieve affordable, community-owned internet access",
    icon: "📡",
  },
  {
    step: "6",
    action: "Transact",
    how: "Join PodCOIN to enable cashless community transactions",
    outcome: "Build a local circular economy",
    icon: "🪙",
  },
  {
    step: "7",
    action: "Advocate",
    how: "Contact local representatives about solar permitting and broadband policy",
    outcome: "Drive public policy change",
    icon: "📢",
  },
];

export default function ActionGuideSection() {
  const { ref, inView } = useInView();

  return (
    <section id="action" className="py-24" style={{ backgroundColor: "oklch(0.97 0.015 80)" }}>
      <div className="container mx-auto px-6 max-w-7xl" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-3 mb-4"
          style={{ opacity: inView ? 1 : 0, transition: "opacity 0.6s ease" }}
        >
          <span className="text-5xl font-black" style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.88 0.025 80)" }}>06</span>
          <div className="leaf-divider" />
          <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
            Take Action
          </span>
        </div>

        <div
          className="max-w-3xl mb-12"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(24px)",
            transition: "opacity 0.65s ease 0.1s, transform 0.65s ease 0.1s",
          }}
        >
          <h2
            className="text-4xl md:text-5xl font-bold leading-tight mb-6"
            style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.22 0.01 65)" }}
          >
            Your Step-by-Step{" "}
            <em style={{ color: "oklch(0.28 0.09 155)" }}>Community Pod Guide</em>
          </h2>
          <p className="text-xl leading-relaxed" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
            The transition away from technofeudalism requires a fundamental shift in how we interact with technology, energy, and each other. Here is a concrete, actionable roadmap your community can follow — starting today.
          </p>
        </div>

        {/* Steps */}
        <div
          className="space-y-4 mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(24px)",
            transition: "opacity 0.65s ease 0.2s, transform 0.65s ease 0.2s",
          }}
        >
          {steps.map((s, i) => (
            <div
              key={s.step}
              className="grid md:grid-cols-12 gap-4 items-center rounded-xl p-5 card-lift"
              style={{
                backgroundColor: "white",
                border: "1px solid oklch(0.88 0.025 80)",
                boxShadow: "0 2px 12px oklch(0.28 0.09 155 / 0.05)",
                animationDelay: `${i * 0.06}s`,
              }}
            >
              {/* Step number */}
              <div className="md:col-span-1 flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-base font-black flex-shrink-0"
                  style={{
                    backgroundColor: "oklch(0.28 0.09 155)",
                    color: "white",
                    fontFamily: "'Playfair Display', serif",
                  }}
                >
                  {s.step}
                </div>
              </div>

              {/* Icon + Action */}
              <div className="md:col-span-2 flex items-center gap-2">
                <span className="text-2xl">{s.icon}</span>
                <span
                  className="font-bold text-lg"
                  style={{ color: "oklch(0.28 0.09 155)", fontFamily: "'Playfair Display', serif" }}
                >
                  {s.action}
                </span>
              </div>

              {/* How */}
              <div className="md:col-span-5">
                <p className="text-sm leading-relaxed" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
                  <span className="font-semibold" style={{ color: "oklch(0.22 0.01 65)" }}>How: </span>
                  {s.how}
                </p>
              </div>

              {/* Outcome */}
              <div className="md:col-span-4">
                <div
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold"
                  style={{
                    backgroundColor: "oklch(0.78 0.16 72 / 0.15)",
                    color: "oklch(0.28 0.09 155)",
                    fontFamily: "'Source Sans 3', sans-serif",
                  }}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-current" />
                  {s.outcome}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Conclusion callout */}
        <div
          className="rounded-2xl p-10 md:p-14 text-center"
          style={{
            background: "linear-gradient(135deg, oklch(0.28 0.09 155) 0%, oklch(0.18 0.07 155) 100%)",
            opacity: inView ? 1 : 0,
            transition: "opacity 0.65s ease 0.5s",
          }}
        >
          <h3
            className="text-3xl md:text-4xl font-bold mb-6"
            style={{ fontFamily: "'Playfair Display', serif", color: "white" }}
          >
            Opt Out. Organize. Build.
          </h3>
          <p
            className="text-xl leading-relaxed mb-8 max-w-2xl mx-auto"
            style={{ color: "oklch(0.88 0.02 80)", fontFamily: "'Source Sans 3', sans-serif", fontWeight: 300 }}
          >
            The balcony solar panels hanging across European apartment buildings are not just energy devices — they are declarations of independence. The community broadband networks being built in Michigan are not just internet services — they are acts of democratic self-determination.
          </p>
          <p
            className="text-lg font-semibold mb-10"
            style={{ color: "oklch(0.78 0.16 72)", fontFamily: "'Playfair Display', serif", fontStyle: "italic" }}
          >
            "The future belongs to those who build it."
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a
              href="https://podcoin.org"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 rounded-full font-semibold text-base transition-all duration-200"
              style={{
                backgroundColor: "oklch(0.78 0.16 72)",
                color: "oklch(0.18 0.07 155)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.88 0.12 72)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72)"; }}
            >
              Join PodCOIN →
            </a>
            <a
              href="https://communityinter.net"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 rounded-full font-semibold text-base transition-all duration-200"
              style={{
                border: "2px solid oklch(0.78 0.16 72 / 0.6)",
                color: "oklch(0.88 0.12 72)",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.78 0.16 72 / 0.1)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
            >
              CommunityInternet.coop →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
