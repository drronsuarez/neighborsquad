import { useEffect, useRef, useState } from "react";

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const benefits = [
  { icon: "💰", title: "Affordability", desc: "An 800-watt unit (~$1,099) can reduce annual electricity bills by $279 or more. Break-even in as little as 25 months." },
  { icon: "🏠", title: "Accessibility", desc: "Plug-and-play design allows renters and apartment dwellers to participate. No complex permits required in growing number of states." },
  { icon: "🛡️", title: "Resilience", desc: "Reduces reliance on centralized grids, protecting households from utility rate hikes and geopolitical energy crises." },
  { icon: "📜", title: "Policy Leverage", desc: "As adoption grows, communities can pressure legislators. 28 US states have already introduced balcony solar legislation." },
];

const steps = [
  { num: "1", title: "Neighborhood Energy Audit", desc: "Identify how many households are renters vs. homeowners and what their average electricity costs are." },
  { num: "2", title: "Form a Community Energy Co-op", desc: "Pool resources to purchase solar equipment at wholesale prices, reducing individual costs significantly." },
  { num: "3", title: "Advocate for Simplified Permitting", desc: "Contact your local representative. 28 US states have introduced legislation to allow plug-in solar without complex interconnection agreements." },
  { num: "4", title: "Explore Shared Battery Storage", desc: "A neighborhood battery bank can store excess solar energy and distribute it during peak demand, further reducing grid dependence." },
];

export default function SolarSection() {
  const { ref, inView } = useInView();

  return (
    <section id="solar" className="py-24" style={{ backgroundColor: "oklch(0.97 0.015 80)" }}>
      <div className="container mx-auto px-6 max-w-7xl" ref={ref}>
        {/* Section label */}
        <div
          className="flex items-center gap-3 mb-4"
          style={{ opacity: inView ? 1 : 0, transition: "opacity 0.6s ease" }}
        >
          <span className="text-5xl font-black" style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.88 0.025 80)" }}>03</span>
          <div className="leaf-divider" />
          <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: "oklch(0.52 0.03 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
            Decentralize Energy
          </span>
        </div>

        {/* Headline */}
        <div
          className="grid lg:grid-cols-2 gap-16 items-center mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(28px)",
            transition: "opacity 0.65s ease 0.1s, transform 0.65s ease 0.1s",
          }}
        >
          <div>
            <h2
              className="text-4xl md:text-5xl font-bold leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.22 0.01 65)" }}
            >
              The Balcony Solar{" "}
              <em style={{ color: "oklch(0.28 0.09 155)" }}>Revolution</em>
            </h2>
            <p className="text-lg leading-relaxed mb-5" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
              Across Europe, and increasingly in the United States, ordinary families are adopting "balcony solar" — simple, plug-and-play solar systems that can be installed without complex permits or landlord approval. In Germany alone, an estimated <strong>4 million households</strong> have installed these systems, which can be ordered directly through retailers like IKEA.
            </p>
            <p className="text-lg leading-relaxed mb-5" style={{ color: "oklch(0.35 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
              These systems can cover up to <strong>20% of a household's annual electricity consumption</strong>, insulating families from volatile energy markets. As the House of El documentary channel notes, the Pentagon can spend billions on military dominance in the Gulf, but it "cannot force Europeans to keep buying oil when they have cheaper, more reliable alternatives literally hanging on their balconies."
            </p>
            <a
              href="https://youtu.be/bt1qBKW7nGY"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-full font-semibold text-sm transition-all duration-200"
              style={{
                backgroundColor: "oklch(0.28 0.09 155)",
                color: "white",
                fontFamily: "'Source Sans 3', sans-serif",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.38 0.09 155)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = "oklch(0.28 0.09 155)"; }}
            >
              ▶ Watch: Europe's Balcony Solar Revolution
            </a>
          </div>

          {/* Image */}
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              boxShadow: "0 12px 48px oklch(0.28 0.09 155 / 0.18)",
              opacity: inView ? 1 : 0,
              transform: inView ? "translateX(0)" : "translateX(28px)",
              transition: "opacity 0.65s ease 0.25s, transform 0.65s ease 0.25s",
            }}
          >
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/117165971/EJnXzSUgo9uiqnKeCdVN32/photo-balcony-solar_f56f7606.jpg"
              alt="Balcony solar panels on a European apartment building"
              className="w-full h-80 object-cover"
            />
          </div>
        </div>

        {/* Benefits grid */}
        <div
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
          style={{
            opacity: inView ? 1 : 0,
            transform: inView ? "translateY(0)" : "translateY(24px)",
            transition: "opacity 0.65s ease 0.35s, transform 0.65s ease 0.35s",
          }}
        >
          {benefits.map((b) => (
            <div
              key={b.title}
              className="rounded-xl p-6 card-lift"
              style={{
                backgroundColor: "white",
                border: "1px solid oklch(0.88 0.025 80)",
                boxShadow: "0 2px 12px oklch(0.28 0.09 155 / 0.06)",
              }}
            >
              <div className="text-3xl mb-3">{b.icon}</div>
              <h3
                className="text-lg font-bold mb-2"
                style={{ fontFamily: "'Playfair Display', serif", color: "oklch(0.28 0.09 155)" }}
              >
                {b.title}
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: "oklch(0.45 0.02 65)", fontFamily: "'Source Sans 3', sans-serif" }}>
                {b.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Organize steps */}
        <div
          className="rounded-2xl p-8 md:p-12"
          style={{
            backgroundColor: "oklch(0.28 0.09 155)",
            opacity: inView ? 1 : 0,
            transition: "opacity 0.65s ease 0.45s",
          }}
        >
          <h3
            className="text-2xl font-bold mb-8 text-center"
            style={{ fontFamily: "'Playfair Display', serif", color: "white" }}
          >
            How to Organize Your Neighborhood for Energy Independence
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step) => (
              <div key={step.num} className="flex flex-col">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-black mb-3"
                  style={{
                    backgroundColor: "oklch(0.78 0.16 72)",
                    color: "oklch(0.18 0.07 155)",
                    fontFamily: "'Playfair Display', serif",
                  }}
                >
                  {step.num}
                </div>
                <h4
                  className="font-bold mb-2"
                  style={{ color: "oklch(0.88 0.12 72)", fontFamily: "'Source Sans 3', sans-serif" }}
                >
                  {step.title}
                </h4>
                <p className="text-sm leading-relaxed" style={{ color: "oklch(0.82 0.02 80)", fontFamily: "'Source Sans 3', sans-serif" }}>
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
          <p
            className="text-xs text-center mt-8"
            style={{ color: "oklch(0.65 0.05 80)", fontFamily: "'Source Sans 3', sans-serif" }}
          >
            Sources:{" "}
            <a href="https://youtu.be/bt1qBKW7nGY" target="_blank" rel="noopener noreferrer" className="link-underline" style={{ color: "oklch(0.78 0.16 72)" }}>
              House of El — Europe's Balcony Solar Revolution
            </a>
            {" "}|{" "}
            <a href="https://reasonstobecheerful.world/diy-balcony-solar-revolution-america/" target="_blank" rel="noopener noreferrer" className="link-underline" style={{ color: "oklch(0.78 0.16 72)" }}>
              Reasons to be Cheerful — DIY Solar Revolution
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
